# The program return values corresponding to failure(s) encountered, warning(s) encountered, connection errors, and no problems found, respectively.
FAILURE = 3
WARNING = 2
CONNECTION_ERROR = 1
GOOD = 0
UNKNOWN_ERROR = -1
